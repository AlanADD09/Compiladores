#ifndef PRETTY_H
#define PRETTY_H
/* pretty.h */
#include "tree.h"
void prettyEXP(EXP *e);

#endif