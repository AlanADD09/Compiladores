#ifndef UTIL_H
#define UTIL_H

typedef char *string;

void *checked_malloc(int);
string String(char *);

#endif
