#ifndef PARSER_H
#define PARSER_H

#include <stdio.h>

extern FILE *yyin; // Declaración externa de yyin
extern int yyparse(); // Declaración externa de yyparse

#endif /* PARSER_H */